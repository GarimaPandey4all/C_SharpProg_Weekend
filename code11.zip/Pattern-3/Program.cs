﻿using System;

namespace Pattern_3
{
    class Program
    {
        static void Main(string[] args)
        {
            for(char i = 'a'; i <= 'e'; i++)
            {
                for(char j = 'a'; j <= 'e'; j++)
                {
                    
                      //Console.Write(i);
                    Console.Write(j);
                }
                Console.WriteLine();
            }
        }
    }
}
