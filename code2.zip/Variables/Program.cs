﻿using System;

namespace Variables
{
    class Program
    {
        static void Main(string[] args)
        {
            //Variable: It is a container that can hold something.

            int a = 30; // Declare and Initialize

            Console.WriteLine(a);

            a = 50;

            Console.WriteLine(a);


            int b = 50, c;

            c = a + b;

            Console.WriteLine(c);
         }
    }
}
