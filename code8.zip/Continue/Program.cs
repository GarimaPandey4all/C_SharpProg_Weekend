﻿using System;

namespace Continue
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i = 1; i < 10; i++)
            {
                if(i == 6)
                {
                    continue;
                }

                Console.WriteLine(i);
            }
        }
    }
}
