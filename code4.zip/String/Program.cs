﻿using System;

namespace String
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = "Brain Mentors";

            Console.WriteLine(text);

            Console.WriteLine(text.Length);

            string str1 = "New ";
            string str2 = "Delhi";

            string str3 = str1 + str2;

            Console.WriteLine(str3);

            Console.WriteLine(string.Concat(str1, str2));

            Console.WriteLine(str1.ToUpper());

            Console.WriteLine(str2.ToLower());
        }
    }
}
