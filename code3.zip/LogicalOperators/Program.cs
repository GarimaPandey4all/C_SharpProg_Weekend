﻿using System;

namespace LogicalOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any number for a:");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any number for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Logical AND Operator:" +((a > b) && (b < a)));

            Console.WriteLine("Logical OR Operator:" +((a > b) || (b < a)));

            Console.WriteLine("Logical Not Operator:" + (!((a > b) && (b < a))));
        }
    }
}
