﻿using System;
using System.Collections;

namespace Queue_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue queue = new Queue();

            queue.Enqueue('A');
            queue.Enqueue('B');
            queue.Enqueue('C');
            queue.Enqueue('D');
            queue.Enqueue('E');

            Console.WriteLine("Queue is:");
            foreach(char ch in queue)
            {
                Console.Write(ch + " ");
            }

            Console.WriteLine();

            queue.Dequeue();

            Console.WriteLine("Queue is:");
            foreach(char ch in queue)
            {
                Console.Write(ch + " ");
            }

            Console.WriteLine();

            queue.Enqueue('F');

            Console.WriteLine("Queue is:");
            foreach(char ch in queue)
            {
                Console.Write(ch + " ");
            }

            Console.WriteLine();

        }
    }
}
