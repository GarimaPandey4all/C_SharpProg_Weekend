﻿using System;

namespace Array_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] lists = new int[5];

            Console.WriteLine("Enter values in an Array:");
            for(int i = 0; i < lists.Length; i++)
            {
                lists[i] = Convert.ToInt32(Console.ReadLine());
            }
            
            Console.WriteLine("Values in an Array:");
            for(int i = 0; i < lists.Length; i++)
            {
                Console.Write("{0}\t", lists[i]);
            }


        }
    }
}
