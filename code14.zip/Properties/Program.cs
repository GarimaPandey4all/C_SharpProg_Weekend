﻿using System;

namespace Properties
{
    class Human
    {
        private string name;

        public string Name // Property
        {
            set
            {
                name = value;
            }

            get
            {
                return name;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Human obj = new Human();

            obj.Name = "Nitin";

            Console.WriteLine(obj.Name);
        }
    }
}
