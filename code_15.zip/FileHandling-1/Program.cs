﻿using System;
using System.IO;

namespace FileHandling_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = "Brain Mentors";
            File.WriteAllText("Test.txt", text);

            Console.WriteLine("Inserted Successfully into a file");
        }
    }
}
