﻿using System;
using System.Collections;

namespace Hashtable_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable hashtable = new Hashtable();

            hashtable.Add("100", "Nitin");
            hashtable.Add("101", "Rahul");
            hashtable.Add("102", "Rishi");
            hashtable.Add("103", "Ravi");
            hashtable.Add("104", "Mohit");

            if(hashtable.ContainsValue("Shivam"))
                Console.WriteLine("He is already in hashtable");
            else
                hashtable.Add("105", "Shivam");

            ICollection key = hashtable.Keys;

            foreach(string str in key)
            {
                Console.WriteLine(str + " : " + hashtable[str]);
            }
        }
    }
}
