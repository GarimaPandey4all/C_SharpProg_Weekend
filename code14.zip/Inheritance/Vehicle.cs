using System;

namespace Inheritance
{
    public class Vehicle // Parent Class or Base Class
    {
        public string brand = "Honda";

        public void Honk()
        {
            Console.WriteLine("Vehicle Horn");
        }
    }
}