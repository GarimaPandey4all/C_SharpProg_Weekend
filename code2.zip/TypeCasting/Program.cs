﻿using System;

namespace TypeCasting
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                1. Implicit: (Automatically)
                2. Explicit: (Manually)          
            */

            int a = 9;
            float b = a; // Implicitly

            Console.WriteLine(b);

            double d = 45.78;
            int c = (int)d; // Explicitly

            Console.WriteLine(c);
        }
    }
}
