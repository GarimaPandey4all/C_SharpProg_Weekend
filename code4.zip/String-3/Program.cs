﻿using System;

namespace String_3
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = "Brain Mentors";

            Console.WriteLine(text[4]);

            Console.WriteLine(text.IndexOf("r"));

            int pos = text.IndexOf("M");

            Console.WriteLine(text.Substring(pos));
        }
    }
}
