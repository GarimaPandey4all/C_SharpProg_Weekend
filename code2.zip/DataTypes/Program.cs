﻿using System;

namespace DataTypes
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                1 byte = 8 bits

                int - 4 bytes - 10, 20, 30...
                long - 8 bytes - 10, 20, 6345801635986348
                float - 4 bytes - 10.60
                double - 8 bytes - 30.949805696903
                char - 2 bytes - F, M
                bool - 1 bit - True , False
                string - 2 bytes per character - Brain Mentors
            */
        }
    }
}
