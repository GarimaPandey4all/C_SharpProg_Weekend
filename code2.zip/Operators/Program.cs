﻿using System;

namespace Operators
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                Expression: (a + b) : a, b - Operands ; +: Operator/Symbol            
            */

            /*Arithmetic Operators*/

            Console.WriteLine("Enter any value for a:");
            int a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Addition: "+(a + b));
            Console.WriteLine("Subtraction: "+(a - b));
            Console.WriteLine("Multiplication: "+(a * b));
            Console.WriteLine("Division: "+(a / b));
            Console.WriteLine("Modulus: "+(a % b)); // Modulus : It gives Remainder

            // a = 5, b = 7
            Console.WriteLine("Pre-Increment: "+(++a));
            Console.WriteLine("Post-Increment: "+(a++));
            Console.WriteLine(a);

            Console.WriteLine("Pre-Decrement: "+(--b));
            Console.WriteLine("Post-Decrement: "+(b--));
            Console.WriteLine(b);
        }
    }
}
