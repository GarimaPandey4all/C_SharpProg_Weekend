﻿using System;

namespace Abstraction_1
{
    //Abstract Class
    abstract class Animal
    {
        //Abstract Method
        public abstract void animalSound(); // Abstract method does not have a body or definition.
    }

    class Dog : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Dog Sound");
        }
    }

    class Cat : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Cat Sound");
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            //Animal obj = new Animal(); // error

            Dog obj = new Dog();
            obj.animalSound();

            
            Cat obj1 = new Cat();
            obj1.animalSound();

        }
    }
}
