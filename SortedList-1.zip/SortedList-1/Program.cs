﻿using System;
using System.Collections;

namespace SortedList_1
{
    class Program
    {
        //Sorted List: it is a combination of ArrayList and Hashtable.

        static void Main(string[] args)
        {
            SortedList sortedList = new SortedList();

            sortedList.Add("100", "Rahul");
            sortedList.Add("101", "Nitin");
            sortedList.Add("102", "Neha");
            sortedList.Add("103", "Ravi");
            sortedList.Add("104", "Ramesh");

            if(sortedList.ContainsValue("Mentors"))
            {
                Console.WriteLine("Already Available");
            }
            else
            {
                sortedList.Add("105", "Mentors");
            }

            ICollection key = sortedList.Keys;

            foreach(string str in key)
            {
                Console.WriteLine(str + " : " + sortedList[str]);
            }
        }
    }
}
