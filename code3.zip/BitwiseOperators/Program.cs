﻿using System;

namespace BitwiseOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any number for a:");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any number for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Bitwise AND Operator:" +(a & b));
            Console.WriteLine("Bitwise OR Operator:" +(a | b));
            Console.WriteLine("Bitwise X-OR Operator:" +(a ^ b));
            Console.WriteLine("Bitwise Left Shift Operator:" +(a<<3));
            Console.WriteLine("Bitwise Right Shift Operator:" +(a>>3));
        }
    }
}
