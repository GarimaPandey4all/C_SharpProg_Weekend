﻿//using System; // namespace

namespace HelloWorld_Nitin
{
    class Program
    {
        static void Main(string[] args) // main() - entry point // void - null or empty
        {
            System.Console.WriteLine("Hello World!"); // print on the output screen
        }
    }
}
