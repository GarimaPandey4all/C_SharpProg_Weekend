﻿using System;

namespace AccessSpecifiers_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Access Specifiers/Modifiers: Public , Private, Protected

            Car obj = new Car("Ford");
            obj.getData();
        }
    }
}
