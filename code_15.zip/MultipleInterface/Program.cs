﻿using System;

namespace MultipleInterface
{
    interface FirstInterface
    {
        void showData();
    }

    interface SecondInterface
    {
        void display();
    }

    class Child : FirstInterface, SecondInterface
    {
        public void display()
        {
            Console.WriteLine("It is First Interface");
        }

        
        public void showData()
        {
            Console.WriteLine("It is Second Interface");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Child obj = new Child();
            obj.showData();
            obj.display();
        }
    }
}
