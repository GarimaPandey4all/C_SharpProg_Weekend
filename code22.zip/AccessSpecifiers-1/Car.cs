using System;

namespace AccessSpecifiers_1
{
    public class Car
    {
        private string name;

        public Car(string n)
        {
            name = n;
        }

        public void getData()
        {
            Console.WriteLine(name);
        }
    }
}