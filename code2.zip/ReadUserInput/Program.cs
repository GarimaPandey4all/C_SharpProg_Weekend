﻿using System;

namespace ReadUserInput
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                1. Convert.ToInt32
                2. Convert.ToInt64
                3. Convert.ToString
                4. Convert.ToBoolean
                5. Convert.ToDouble
            */


            Console.WriteLine("Enter any number:");
            int number = Convert.ToInt32(Console.ReadLine()); // string - ""

            Console.WriteLine(number);

            Console.WriteLine("Enter any number:");
            double doub = Convert.ToDouble(Console.ReadLine()); // string - ""

            Console.WriteLine(doub);

            Console.WriteLine("Enter any state:");
            bool state = Convert.ToBoolean(Console.ReadLine()); // string - ""

            Console.WriteLine(state);
        }
    }
}
