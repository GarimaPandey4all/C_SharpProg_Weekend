﻿using System;

namespace Constant
{
    class Program
    {
        static void Main(string[] args)
        {
            const int a = 60;

            Console.WriteLine(a);

//error-            a = 70; // re-assign

        }
    }
}
