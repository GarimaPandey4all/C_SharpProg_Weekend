﻿using System;
using System.Collections;

namespace ArrayList_1
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arrayList = new ArrayList();

            Console.WriteLine("Insertion in Array");
            arrayList.Add(10);
            arrayList.Add(20);
            arrayList.Add(30);
            arrayList.Add(40);
            arrayList.Add(50);           

            Console.WriteLine("Count is:{0} ",arrayList.Count);
            Console.WriteLine("Capacity is:{0} ",arrayList.Capacity);

            Console.WriteLine("Value in Array are");
            foreach(int i in arrayList)
            {
                Console.Write(i + " ");
            }

            Console.WriteLine();

            arrayList.Remove(50);
            Console.WriteLine("Value in Array are");
            foreach(int i in arrayList)
            {
                Console.Write(i + " ");
            }

            Console.WriteLine();

            Console.WriteLine("Count is:{0} ",arrayList.Count);
            Console.WriteLine("Capacity is:{0} ",arrayList.Capacity);
        }
    }
}
