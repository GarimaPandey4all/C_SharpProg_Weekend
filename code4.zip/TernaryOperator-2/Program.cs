﻿using System;

namespace TernaryOperator_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any number:");
            int a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any number:");
            int b = Convert.ToInt32(Console.ReadLine());

            string result = (a > b) ? "A is Greater" : "B is Greater";

            Console.WriteLine(result);
        }
    }
}
