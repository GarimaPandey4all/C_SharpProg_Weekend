﻿using System;

namespace Exception_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter value for a:");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter value for b:");
            int b = Convert.ToInt32(Console.ReadLine());

            try{
                int c = a / b;
                Console.WriteLine("Division is: "+c);
            }

            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

            finally
            {
                Console.WriteLine("Outside the Try-Catch Blocks");
            }

        }
    }
}
