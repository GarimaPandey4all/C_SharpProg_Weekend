﻿using System;

namespace ClassAndObject_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Car Honda = new Car();
            Honda.year = "2020";
            Honda.brand = "Honda City";
            Honda.model = "Honda 2020";

            Console.WriteLine(Honda.year);
            Console.WriteLine(Honda.brand);
            Console.WriteLine(Honda.model);

        }
    }
}
