﻿using System;

namespace GenericClass
{
    public class MyGeneric<T>
    {
        private T[] array;

        public MyGeneric(int size)
        {
            array = new T[size];
        }

        public void setItem(int index, T value)
        {
            array[index] = value;
        }

        public T getItem(int index)
        {
            return array[index];
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            MyGeneric<int> intArray = new MyGeneric<int>(5);

            //Set values 
            for(int i = 0; i < 5; i++)
            {
                intArray.setItem(i, i * 5);
            }

            //get values
            for(int i = 0; i < 5; i++)
            {
                Console.Write(intArray.getItem(i) + " ");
            }

            Console.WriteLine();

            MyGeneric<char> charArray = new MyGeneric<char>(5);

            //Set values 
            for(int i = 0; i < 5; i++)
            {
                charArray.setItem(i, (char)(i + 65));
            }

            //get values
            for(int i = 0; i < 5; i++)
            {
                Console.Write(charArray.getItem(i) + " ");
            }

            Console.WriteLine();



        }
    }
}
