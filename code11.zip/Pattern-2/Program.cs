﻿using System;

namespace Pattern_2
{
    class Program
    {
        static void Main(string[] args)
        {
            for(char i = 'A'; i <= 'E'; i++)
            {
                for(char j = 'A'; j <= 'E'; j++)
                {
                    
                      Console.Write(i);
                    //Console.Write(j);
                }

                Console.WriteLine();
            }
        }
    }
}
