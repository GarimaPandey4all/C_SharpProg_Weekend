﻿using System;

namespace Exception_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                Exceptions:

                try and catch:

                try statement: It allows you to declare block of code to be tested for errors.

                catch statement: It allows you to define a block of code to be executed.
            */

            try 
            {
                int[] digits = {10, 20, 30, 40};
                Console.WriteLine(digits[5]);
            }

            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                //Console.WriteLine("Index out of range");
            }
        }
    }
}
