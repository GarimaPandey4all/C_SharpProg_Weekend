﻿using System;

namespace String_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string str1 = "New";
            string str2 = "Delhi";

            string str3 = $"Str3 is: {str1} {str2}";

            Console.WriteLine(str3);
        }
    }
}
