﻿using System;
using System.IO;

namespace FileHandling_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = File.ReadAllText("Test.txt");
            Console.WriteLine(text);
        }
    }
}
