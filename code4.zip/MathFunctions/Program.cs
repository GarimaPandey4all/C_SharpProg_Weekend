﻿using System;

namespace MathFunctions
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Max value is:" + Math.Max(10, 30));

            Console.WriteLine("Min value is:" + Math.Min(40, 20));

            Console.WriteLine("Sqrt value is:" + Math.Sqrt(9));

            Console.WriteLine("Round value is:" + Math.Round(5.97));

            Console.WriteLine("Absolute value is:" + Math.Abs(-5.9));
        }
    }
}
