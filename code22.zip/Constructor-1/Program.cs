﻿using System;

namespace Constructor_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                Constructor: It is a special type of method because the class name and the constructor name both are same.
                It is used to initialize objects. It is called when an object of a class is created.
            */

            Car obj = new Car();

            Console.WriteLine(obj.model);

        }
    }
}
