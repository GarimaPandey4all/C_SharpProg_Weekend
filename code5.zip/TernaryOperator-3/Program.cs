﻿using System;

namespace TernaryOperator_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 7, b = 5, c = 3;

            int result = (a > b) ? a : ((b > c) ? b : c);

            Console.WriteLine(result);
        }
    }
}
