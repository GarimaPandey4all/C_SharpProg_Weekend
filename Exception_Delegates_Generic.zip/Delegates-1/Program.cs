﻿using System;

//Delegate Declaration
delegate int NChanger(int n);

namespace Delegates_1
{
    class Program
    {
        static int num = 10;

        public static int Sum(int a)
        {
            num += a;
            return num;
        }

        
        public static int Mul(int a)
        {
            num *= a;
            return num;
        }

        
        public static int display()
        {
            return num;
        }

        static void Main(string[] args)
        {
            NChanger obj1 = new NChanger(Sum);
            NChanger obj2 = new NChanger(Mul);

            obj1(20);
            Console.WriteLine("Addition is:"+display());
            
            obj2(5);
            Console.WriteLine("Multiplication is:"+display());
        }
    }
}
