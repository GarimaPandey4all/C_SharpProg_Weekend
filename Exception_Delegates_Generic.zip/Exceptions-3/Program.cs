﻿using System;

namespace Exceptions_3
{
    class Program
    {   
        static void isEven(int n)
        {
            if(n <= 0)
            {
                throw new ArithmeticException("Not matched with the limit");
            }
            else
            {
                string text = ((n % 2)==0) ? "Number is Even" : "Number is Odd";
                Console.WriteLine(text);
            }
        }


        static void Main(string[] args)
        {
            isEven(0);
        }
    }
}
