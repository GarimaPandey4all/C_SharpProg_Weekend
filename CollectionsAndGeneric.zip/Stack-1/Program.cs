﻿using System;
using System.Collections;

namespace Stack_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack stack = new Stack();

            stack.Push('A');
            stack.Push('B');
            stack.Push('C');
            stack.Push('D');
            stack.Push('E');

            Console.WriteLine("Stack is:");
            foreach(char ch in stack)
            {
                Console.Write(ch + " ");
            }

            Console.WriteLine();

            Console.WriteLine("Top value of stack is: {0}", stack.Peek());

            stack.Pop();

            Console.WriteLine("Stack is:");
            foreach(char ch in stack)
            {
                Console.Write(ch + " ");
            }

            Console.WriteLine();

            Console.WriteLine("Top value of stack is: {0}", stack.Peek());
        }
    }
}
