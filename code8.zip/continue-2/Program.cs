﻿using System;

namespace continue_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;

            while(i <= 10)
            {
                if(i == 3)
                {
                    ++i;
                    continue;
                }
                Console.WriteLine(i);
                i++;
            }
        }
    }
}
