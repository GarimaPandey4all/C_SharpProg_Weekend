﻿using System;

namespace function_1
{
    class Program
    {
        //1. Function without arguments and without return type

        //Function Definition
        static void HelloWorld() // void = empty / null / no return type
        {
            Console.WriteLine("Hello World");
        }

        static void Main(string[] args)
        {
            //Function Calling
            HelloWorld();
            HelloWorld();
            HelloWorld();
            HelloWorld();
            HelloWorld();
        }
    }
}
