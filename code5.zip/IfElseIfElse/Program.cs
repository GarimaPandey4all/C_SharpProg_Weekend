﻿using System;

namespace IfElseIfElse
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                a, b, c

                a > b && a >c

                b > c

                c
            
            */

            Console.WriteLine("Enter value for a:");
            int a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter value for b:");
            int b = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter value for c:");
            int c = Convert.ToInt32(Console.ReadLine());

            if(a > b && a > c)
            {
                Console.WriteLine("A is Greater");
            }
            else if(b > c)
            {
                Console.WriteLine("B is Greater");
            }
            else
            {
                Console.WriteLine("C is Greater");
            }
        }
    }
}
