﻿using System;
using System.Collections;

namespace ArrayList
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arrayList = new ArrayList();

            Console.WriteLine("Insertion in Array");
            arrayList.Add(10);
            

            Console.WriteLine("Count is:{0} ",arrayList.Count);
        }
    }
}
