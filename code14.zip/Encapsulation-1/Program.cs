﻿using System;

namespace Encapsulation_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Car obj = new Car();
            obj.getData();
        }
    }
}
