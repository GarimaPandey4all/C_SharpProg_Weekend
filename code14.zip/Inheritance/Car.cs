namespace Inheritance
{
    public class Car : Vehicle // Car: Child Class or Derived Class
    {
        public string name = "Cereta";
    }
}