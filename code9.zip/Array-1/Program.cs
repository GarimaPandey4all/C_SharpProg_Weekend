﻿using System;

namespace Array_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Array: It is a collection of similar types of data. It contains multiple values in a single variable.
            //It is a contiguous memory allocation.

            int[] marks = {10, 20, 30, 40, 50}; // []-subsrcipt operator/square bracket

            /*
            Console.WriteLine(marks[0]);
            Console.WriteLine(marks[1]);
            Console.WriteLine(marks[2]);
            Console.WriteLine(marks[3]);
            Console.WriteLine(marks[4]);
            */

            Console.WriteLine(marks.Length);

            for(int i = 0; i < marks.Length; i++)
            {
                Console.Write("{0}\t", marks[i]);
            }
        }
    }
}
