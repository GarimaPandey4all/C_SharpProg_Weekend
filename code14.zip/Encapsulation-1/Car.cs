using System;

namespace Encapsulation_1
{
    public class Car
    {
        public string name;

        public Car()
        {
            name = "Honda";
        }

        public void getData()
        {
            Console.WriteLine(name);
        }
    }
}