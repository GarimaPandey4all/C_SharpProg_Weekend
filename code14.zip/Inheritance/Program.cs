﻿using System;

namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Car obj = new Car();

            obj.Honk();

            Console.WriteLine(obj.brand + " " + obj.name);
        }
    }
}
