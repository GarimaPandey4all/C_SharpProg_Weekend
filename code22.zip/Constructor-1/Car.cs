namespace Constructor_1
{
    public class Car
    {
        public string model;

        public Car() // Constructor
        {
            model = "Honda 2020";
        }
    }
}