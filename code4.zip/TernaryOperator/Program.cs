﻿using System;

namespace TernaryOperator
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                Ternary Operator / Conditional Operator

                (Expression-1)      (Expression-2)      (Expression-3)
                (Condition)     ? (true)            : (false);
            
            */

            Console.WriteLine("Enter any number:");
            int number = Convert.ToInt32(Console.ReadLine());

            string result = ((number % 2) == 0) ? "Number is Even" : "Number is Odd";

            Console.WriteLine(result);
        }
    }
}
