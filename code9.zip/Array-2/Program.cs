﻿using System;
using System.Linq;

namespace Array_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = {30, 20, 10, 50, 40};

            Array.Sort(arr);

            /*
            for(int i = 0; i < arr.Length; i++)
            {
                Console.Write("{0}\t", arr[i]);
            }
            */

            foreach(int i in arr)
            {
                Console.WriteLine(i);
            }

            for(int i = arr.Length - 1; i >= 0; i--)
            {
                Console.Write("{0}\t", arr[i]);
            }

            Console.WriteLine("\nSum of the Array is:"+arr.Sum());
            Console.WriteLine("Max Value of the Array is:"+arr.Max());
            Console.WriteLine("Min Value of the Array is:"+arr.Min());
        }
    }
}
