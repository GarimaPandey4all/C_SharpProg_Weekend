using System;

namespace ClassAndObject_3
{
    public class Car
    {
        public string name;
        public string brand;
        public string model;

        public void setData(string n, string b, string m)
        {
            name = n;
            brand = b;
            model = m;
        }

        public void getData()
        {
            Console.WriteLine("Car name is:"+name);
            Console.WriteLine("Car brand is:"+brand);
            Console.WriteLine("Car model is:"+model);
        }

    }
}