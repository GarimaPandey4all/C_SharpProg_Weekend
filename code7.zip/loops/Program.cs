﻿using System;

namespace loops
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                Three Types of loop:

                1. for loop
                2. while loop
                3. do-while loop

                1. for loop            

                syntax:

                for(initialization; condition; increment/decrement)
                {
                    //block of loop
                }

                2. while loop

                initialization

                while(condition)
                {
                    //block of loop
                    increment/decrement
                }

                3. do-while loop

                initialization

                do
                {
                    //block of loop
                    increment/decrement
                }while(condition);

            */
        }
    }
}
