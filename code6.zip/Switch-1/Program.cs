﻿using System;

namespace Switch_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Switch: Menu Driven Program

            int a, b;

            Console.WriteLine("-----Calculator------");
            Console.WriteLine("Press 1. Addition");
            Console.WriteLine("Press 2. Subtraction");
            Console.WriteLine("Press 3. Multiplication");
            Console.WriteLine("Press 4. Division");

            Console.WriteLine("Enter your Choice:");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch(choice)
            {
            case 1:
            Console.WriteLine("Enter value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Addition is:" +(a + b));

            break;

            case 2:

            Console.WriteLine("Enter value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Subtraction is:" +(a - b));

            break;

            case 3:

            Console.WriteLine("Enter value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Multiplication is:" +(a * b));

            break;

            case 4:

            Console.WriteLine("Enter value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Division is:" +(a / b));

            break;

            default:
            Console.WriteLine("Invalid Choice");
            break;

            }
        }
    }
}
