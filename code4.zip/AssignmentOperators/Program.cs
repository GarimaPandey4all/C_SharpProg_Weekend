﻿using System;

namespace AssignmentOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            //int a = 10;

            int sum = 0;

            Console.WriteLine("Enter any value:");
            int a = Convert.ToInt32(Console.ReadLine());

            sum += a; // sum = sum + a;

            Console.WriteLine(sum);
        }
    }
}
