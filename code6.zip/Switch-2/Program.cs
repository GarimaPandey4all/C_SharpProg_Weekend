﻿using System;

namespace Switch_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Press a. X-OR Operator");
            Console.WriteLine("Press b. Even-Odd");
            Console.WriteLine("Press c. Swap Numbers");
            Console.WriteLine("Press d. Largest Number");
            Console.WriteLine("Press e. Swap without using third variable");

            Console.WriteLine("Enter your choice:");
            char choice = Convert.ToChar(Console.ReadLine());

            switch(choice)
            {
                case 'a':
                int a = 5, b = 9;

                Console.WriteLine("X-OR is: "+(a ^ b));

                break;

                case 'b':
                int number;

                Console.WriteLine("Enter any number:");
                number = Convert.ToInt32(Console.ReadLine());

                string msg = ((number % 2) == 0) ? "Number is Even" : "Number is Odd";

                Console.WriteLine(msg);

                break;

                case 'c':

                int x = 10, y = 20;

                Console.WriteLine("Before Swapping x={0} and y={1}", x, y);

                int temp = x;
                x = y;
                y = temp;

                Console.WriteLine("After Swapping x={0} and y={1}", x, y);

                break;

                case 'd':

                int e = 6, f = 7, g = 9;

                int result = (e > f) ? ((e > g) ? e : g) : ((f > g) ? f : g);

                Console.WriteLine("Largest number is:" +result);

                break;

                case 'e':

                int h = 5 , i = 8;

                Console.WriteLine("Before Swapping h={0} and i={1}", h, i);

                h = h ^ i;
                i = h ^ i;
                h = h ^ i;

                Console.WriteLine("After Swapping h={0} and i={1}", h, i);

                break;

                default:
                Console.WriteLine("Inavlid Choice");
                break;

            }
        }
    }
}
