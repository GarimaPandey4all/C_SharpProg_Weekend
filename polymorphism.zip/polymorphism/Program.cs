﻿using System;

namespace polymorphism
{
    class Animal
    {
        public virtual void animalSound()
        {
            Console.WriteLine("Animal Sound");
        }
    }

    class Dog : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Dog Sound");
        }
    }

    class Cat : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Cat Sound");
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            //Polymorphism: Many Forms

            Animal obj = new Animal();
            Animal obj1 = new Dog();
            Animal obj2 = new Cat();

            obj.animalSound();
            obj1.animalSound();
            obj2.animalSound();
        }
    }
}
