﻿using System;

namespace Function_3
{
    class Program
    {
        //3. Function without arguments and with return type

        static int Sum()
        {
            int a, b;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            return (a + b);
        }

        static void Main(string[] args)
        {
            int result = Sum();

            Console.WriteLine("Addition is: "+result);

            result = Sum();

             Console.WriteLine("Addition is: "+result);
        }
    }
}
