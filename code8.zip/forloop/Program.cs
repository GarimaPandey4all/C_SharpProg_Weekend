﻿using System;

namespace forloop
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i = 1; i <= 5; i++)
            {
                Console.WriteLine("Hello World");
            }
        }
    }
}
