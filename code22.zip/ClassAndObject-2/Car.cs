namespace ClassAndObject_2
{
    public class Car
    {
        public string name = "Cereta";
        public string model = "XUV";
    }
}