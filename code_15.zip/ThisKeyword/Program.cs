﻿using System;

namespace ThisKeyword
{
    class Sum
    {
        public int a, b;

        public Sum(int a, int b)
        {
            this.a = a;
            this.b = b;
        }

        public void display()
        {
            Console.WriteLine("Addition is: "+(a + b));
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Sum obj = new Sum(10, 20);
            obj.display();
            
        }
    }
}
