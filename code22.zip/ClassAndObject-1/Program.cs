﻿using System;

namespace ClassAndObject_1
{
    class Human
    {
        string name = "Nitin"; // data member/field/attribute/Instance variable

        static void Main(string[] args)
        {
            Human obj = new Human(); // obj = object/reference variable
            Console.WriteLine(obj.name);

        }
    }
}
