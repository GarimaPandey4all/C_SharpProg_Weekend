﻿using System;

namespace Properties_2
{
    class Human
    {
        public string Name
        {
            get;
            set;
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            Human obj = new Human();

            obj.Name = "Nitin";

            Console.WriteLine(obj.Name);
        }
    }
}
