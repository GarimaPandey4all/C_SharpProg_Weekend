namespace ClassAndObject_4
{
    public class Car
    {
        public string year;
        public string brand;
        public string model;
    }
}