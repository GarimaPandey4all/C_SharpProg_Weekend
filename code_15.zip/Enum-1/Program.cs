﻿using System;

namespace Enum_1
{
    class Program
    {
        enum Week
            {
                Monday = 1,
                Tuesday,
                Wednesday,
                Thursday,
                Friday,
                Saturday,
                Sunday
            }


        static void Main(string[] args)
        {
            //Enum: Enumeration is a special class in C#. That represents a group of constants.

            //Week Today = Week.Tuesday;
            //Console.WriteLine(Today);

            int Today = (int) Week.Thursday;
            Console.WriteLine(Today);            
        }
    }
}
