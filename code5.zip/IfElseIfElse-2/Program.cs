﻿using System;

namespace IfElseIfElse_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int eng, maths, hindi, science, drawing;

            Console.WriteLine("Enter your marks:");
            eng = Convert.ToInt32(Console.ReadLine());
            maths = Convert.ToInt32(Console.ReadLine());
            hindi = Convert.ToInt32(Console.ReadLine());
            science = Convert.ToInt32(Console.ReadLine());
            drawing = Convert.ToInt32(Console.ReadLine());

            int sum = eng + maths + hindi + science + drawing;

            int percentage = sum / 5;

            Console.WriteLine("Percenatge is:"+percentage);

            if(percentage >= 50 && percentage <= 60)
            Console.WriteLine("Grade D");
            else if(percentage >= 60 && percentage <= 70)
            Console.WriteLine("Grade C");
            else if(percentage >= 70 && percentage <= 80)
            Console.WriteLine("Grade B");
            else if(percentage >= 80 && percentage <= 100)
            Console.WriteLine("Grade A");
            else
            Console.WriteLine("Fail..");
        }
    }
}
