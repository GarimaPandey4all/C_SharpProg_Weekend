﻿using System;

namespace Interface_1
{
    //interface : Abstract Class
    interface Animal
    {
        void animalSound(); // bydefault : abstract method
    }

    class Dog : Animal
    {
        public void animalSound()
        {
            Console.WriteLine("Dog Sound");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Dog obj = new Dog();
            obj.animalSound();
        }
    }
}
