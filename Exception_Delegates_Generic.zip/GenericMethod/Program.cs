﻿using System;

namespace GenericMethod
{
    class Program
    {
        static void Swap<T>(T a, T b)
        {
            Console.WriteLine("Before Swapping {0} and {1}:", a, b);

            T temp = a;
            a = b;
            b = temp;

            Console.WriteLine("After Swapping {0} and {1}:", a, b);
        }

        static void Main(string[] args)
        {
            Swap(10, 20);
            Swap(23.5F, 45.6F);
        }
    }
}
